﻿using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.BlazorIdentity.Pages.Manage;
using StudentInformation.Models;

namespace StudentInformation.Data
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        {
        }
        public DbSet<Student> Students { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Instructor> Instructors { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
        public DbSet<Section> Sections { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasKey(x => x.StudentId);
                entity.Property(x => x.StudentNo).IsRequired();
                entity.Property(x => x.FirstName).IsRequired();
                entity.Property(x => x.LastName).IsRequired();
                entity.Property(x => x.Gender);
                entity.Property(x => x.DateOfBirth);
                entity.Property(x => x.Email);
            });

            modelBuilder.Entity<Course>(entity =>
            {
                entity.HasKey(x => x.CourseId);
                entity.Property(x => x.Code).IsRequired();
                entity.Property(x => x.Title).IsRequired();
                entity.Property(x => x.Units).IsRequired();
            });

            modelBuilder.Entity<Department>(entity =>
            {
                entity.HasKey(x => x.DepartmentId);
                entity.Property(x => x.code).IsRequired();
                entity.Property(x => x.name).IsRequired();
            });

            modelBuilder.Entity<Instructor>(entity =>
            {
                entity.HasKey(x => x.InstructorId);
                entity.Property(x => x.EmployeeNo).IsRequired();
                entity.Property(x => x.FirstName).IsRequired();
                entity.Property(x => x.LastName).IsRequired();
                entity.Property(x => x.Email).IsRequired();
            });

            modelBuilder.Entity<Enrollment>(entity =>
            {
                entity.HasKey(x => x.EnrollmentId);

                entity.HasOne<Student>()
                      .WithMany()
                      .HasForeignKey(x => x.StudentId);

                entity.HasOne<Course>()
                      .WithMany()
                      .HasForeignKey(x => x.CourseId);

                entity.Property(x => x.Semester).IsRequired();
                entity.Property(x => x.Grade);
            });

            modelBuilder.Entity<Section>(entity =>
            {
                entity.HasKey(x => x.SectionId);
                entity.Property(x => x.SectionCode).IsRequired();

                entity.HasOne<Course>()
                .WithMany()
                .HasForeignKey(x => x.CourseId);

                entity.HasOne<Instructor>()
                .WithMany()
                .HasForeignKey(x => x.InstructorId);

                entity.Property(x => x.Room).IsRequired();
                entity.Property(x => x.Schedule).IsRequired();
            });

        }
    }
}
