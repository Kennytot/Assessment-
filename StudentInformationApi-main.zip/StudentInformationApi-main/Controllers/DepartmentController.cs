﻿using StudentInformation.Data; // Ensure this matches your actual namespace for ApplicationDBContext
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentInformation.Models;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly ApplicationDBContext _dbContext;

        public DepartmentController(ApplicationDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllAsync()
        {
            var departments = await _dbContext.Departments
                .AsNoTracking()
                .ToListAsync();

            return Ok(departments);
        }


        [HttpPut]
        [Route("{id:Guid}")]
        public async Task<IActionResult> UpdateAsync(Guid id, [FromBody] Department department)
        {
            if (department == null)
            {
                return BadRequest();
            }

            var existingDept = await _dbContext.Departments.FindAsync(id);

            if (existingDept == null)
            {
                return NotFound();
            }

            // Update properties
            existingDept.code = department.code;
            existingDept.name = department.name;
            existingDept.office = department.office;

            await _dbContext.SaveChangesAsync();

            return Ok(existingDept);
        }

        [HttpGet]
        [Route("{id:Guid}", Name = "GetDepartment")]
        public async Task<IActionResult> GetByIdAsync(Guid id)
        {
            var department = await _dbContext.Departments
                .FirstOrDefaultAsync(x => x.DepartmentId == id);

            if (department == null) return NotFound();

            return Ok(department);
        }

        [HttpPost]
        public async Task<IActionResult> CreateAsync([FromBody] Department department)
        {
            if (department == null) return BadRequest();

            department.DepartmentId = Guid.NewGuid();

            await _dbContext.Departments.AddAsync(department);
            await _dbContext.SaveChangesAsync();

            return CreatedAtRoute("GetDepartment", new { id = department.DepartmentId }, department);
        }
        [HttpDelete]
        [Route("{id:Guid}")]
        public async Task<IActionResult> DeleteAsync(Guid id)
        {
            var department = await _dbContext.Departments.FindAsync(id);

            if (department == null)
            {
                return NotFound();
            }

            _dbContext.Departments.Remove(department);
            await _dbContext.SaveChangesAsync();

            return Ok(new { Message = "Department deleted successfully" });
        }
    }
}