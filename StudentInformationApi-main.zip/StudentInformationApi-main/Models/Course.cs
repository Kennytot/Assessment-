﻿namespace StudentInformation.Models
{
    public class Course
    {
        public Guid CourseId { get; set; }
        public string Code { get; set; }
        public string Title { get; set; }
        public string Units { get; set; }
    }
}
