﻿namespace StudentInformation.Models
{
    public class Department
    {
        public Guid DepartmentId { get; set; }
        public string code { get; set; }
        public string name { get; set; }
        public string office { get; set; }
    }
}
