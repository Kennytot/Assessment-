﻿namespace StudentInformation.Models
{
    public class Instructor
    {
        public Guid InstructorId { get; set; }
        public string EmployeeNo { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public string Email { get; set; } 
        public Guid DepartmentId { get; set; }
    }
}
