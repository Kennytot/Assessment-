﻿using CSCPersonalDataSheet.Models;
using Microsoft.EntityFrameworkCore;

namespace CSCPersonalDataSheet.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Applicant> Applicants { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure table name
            modelBuilder.Entity<Applicant>().ToTable("Applicants");

            // Configure indexes
            modelBuilder.Entity<Applicant>()
                .HasIndex(a => a.EmailAddress)
                .IsUnique();
        }
    }
}
