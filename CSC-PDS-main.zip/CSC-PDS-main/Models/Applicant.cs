﻿using System.ComponentModel.DataAnnotations;

namespace CSCPersonalDataSheet.Models
{
    public class Applicant
    {
        [Key]
        public int ApplicantId { get; set; }

        [Required(ErrorMessage = "Last Name is requred")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "First Name is requred")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Display(Name = "Middle Name")]
        public string? MiddleName { get; set; }

        [Display(Name = "Suffix (Jr., Sr., III")]
        public string? Suffix { get; set; }

        [Required(ErrorMessage = "Birth Date is requred")]
        [DataType(DataType.Date)]
        [Display(Name = "Birth Date")]
        public DateTime BirthDate { get; set; }

        [Required(ErrorMessage = "Sex is requred")]
        public string Sex { get; set; }

        [Required(ErrorMessage = "Civil Status is requred")]
        [Display(Name = "Civil Status")]
        public string CivilStatus { get; set; }

        [Required(ErrorMessage = "Contact Number is requred")]
        [Display(Name = "Contact Number")]
        [Phone]
        [RegularExpression(@"^\d{11}$", ErrorMessage = "Contact Number must be 11 digits.")]
        public string ContactNumber { get; set; }

        [Required(ErrorMessage = "Email Address is requred")]
        [EmailAddress]
        [Display(Name = "Email Address")]
        public string EmailAddress { get; set; }

        [Display(Name = "Place of Birth")]
        public string? PlaceOfBirth { get; set; }

        [Display(Name = "Citizenship")]
        public string Citizenship { get; set; }

        [Display(Name = "Residential Address")]
        public string? ResidentialAddress { get; set; }

        [Display(Name = "Permanent Address")]
        public string? PermanentAddress { get; set; }

        [Display(Name = "Created At")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [Display(Name = "Updated At")]
        public DateTime UpdatedAt { get; set; }

        [Display(Name = "Full Name")]
        public string FullName => $"{LastName}, {FirstName} {(string.IsNullOrEmpty(MiddleName) ? "" : MiddleName[0] + ".")} {(string.IsNullOrEmpty(Suffix) ? "" : Suffix)}".Trim();

    }
}
