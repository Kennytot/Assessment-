﻿using Student_Information_System.Data;
using Student_Information_System.Models;


namespace StudentRecordsManagement.Data
{
    public static class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            // Check if data exists
            if (context.Departments.Any())
            {
                return; // Database has been seeded
            }

            // Seed Departments
            var departments = new Department[]
            {
                new Department { DepartmentName = "Computer Science", DepartmentCode = "CS", Location = "Building A" },
                new Department { DepartmentName = "Mathematics", DepartmentCode = "MATH", Location = "Building B" },
                new Department { DepartmentName = "Physics", DepartmentCode = "PHY", Location = "Building C" }
            };
            context.Departments.AddRange(departments);
            context.SaveChanges();

            // Seed Courses
            var courses = new Course[]
            {
                new Course { CourseName = "BSc Computer Science", CourseCode = "BSCS", Credits = 4, DepartmentId = 1, Description = "Bachelor in Computer Science" },
                new Course { CourseName = "BSc Mathematics", CourseCode = "BSMATH", Credits = 4, DepartmentId = 2, Description = "Bachelor in Mathematics" }
            };
            context.Courses.AddRange(courses);
            context.SaveChanges();
        }
    }
}
