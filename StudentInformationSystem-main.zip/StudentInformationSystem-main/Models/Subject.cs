﻿using System.ComponentModel.DataAnnotations;

namespace Student_Information_System.Models
{
    public class Subject
    {
        [Key]
        public int SubjectId { get; set; }

        [Required]
        [Display(Name = "Subject Name")]
        public string SubjectName { get; set; }

        [Required]
        [Display(Name = "Subject Code")]
        public string SubjectCode { get; set; }

        [Required]
        [Range(1, 5)]
        public int Credits { get; set; }

        // Foreign Key
        public int InstructorId { get; set; }

        // Navigation Properties
        public virtual Instructor Instructor { get; set; }
        public virtual ICollection<Enrollment> Enrollments { get; set; }
    }
}
