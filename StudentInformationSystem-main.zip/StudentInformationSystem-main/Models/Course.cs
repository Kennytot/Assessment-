﻿using System.ComponentModel.DataAnnotations;

namespace Student_Information_System.Models
{
    public class Course
    {
        [Key]
        public int CourseId { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Course Name")]
        public string CourseName { get; set; }

        [Required]
        [StringLength(20)]
        [Display(Name = "Course Code")]
        public string CourseCode { get; set; }

        [Required]
        [Range(1, 4)]
        public int Credits { get; set; }

        [StringLength(500)]
        public string Description { get; set; }

        // Foreign Key
        public int DepartmentId { get; set; }

        // Navigation Properties
        public virtual Department Department { get; set; }
        public virtual ICollection<Student> Students { get; set; }
    }
}
