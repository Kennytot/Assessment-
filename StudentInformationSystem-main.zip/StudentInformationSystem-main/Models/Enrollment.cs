﻿using System.ComponentModel.DataAnnotations;

namespace Student_Information_System.Models
{
    public class Enrollment
    {
        [Key]
        public int EnrollmentId { get; set; }

        [Required]
        public int StudentId { get; set; }

        [Required]
        public int SubjectId { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Enrollment Date")]
        public DateTime EnrollmentDate { get; set; }

        [StringLength(2)]
        [RegularExpression(@"^[A-F]$", ErrorMessage = "Grade must be A, B, C, D, or F")]
        public string Grade { get; set; }

        // Navigation Properties
        public virtual Student Student { get; set; }
        public virtual Subject Subject { get; set; }
    }
}
