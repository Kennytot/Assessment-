﻿namespace Student_Information_System.Models.ViewModels
{
    public class StudentRecordViewModel
    {
        public Student Student { get; set; }
        public List<Enrollment> Enrollments { get; set; }
        public decimal TotalCredits { get; set; }
        public double GPA { get; set; }
    }
}
