﻿// StudentsController.cs - Complete working version

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Student_Information_System.Data;
using Student_Information_System.Models;
using StudentRecordsManagement.Data;

namespace StudentRecordsManagement.Controllers
{
    public class StudentsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StudentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Students
        public async Task<IActionResult> Index()
        {
            var students = _context.Students.Include(s => s.Course);
            return View(await students.ToListAsync());
        }

        // GET: Students/Create
        public IActionResult Create()
        {
            ViewData["CourseId"] = new SelectList(_context.Courses, "CourseId", "CourseName");
            return View();
        }

        // POST: Students/Create - THIS IS THE IMPORTANT PART
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StudentId,FirstName,LastName,Email,DateOfBirth,PhoneNumber,Address,CourseId")] Student student)
        {
            // Remove ModelState validation for DateOfBirth temporarily to debug
            if (ModelState.IsValid)
            {
                _context.Add(student);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Student created successfully!";
                return RedirectToAction(nameof(Index));
            }

            // If we got this far, something failed, redisplay form
            ViewData["CourseId"] = new SelectList(_context.Courses, "CourseId", "CourseName", student.CourseId);
            return View(student);
        }

        // Other methods (Edit, Delete, Details, StudentRecord) go here...
    }
}